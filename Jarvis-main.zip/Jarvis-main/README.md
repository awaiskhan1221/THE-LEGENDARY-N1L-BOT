#### JARVIS MD WHATSAPP BOT
jarvis md is Multi Device whatsapp bot
***

### SETUP JARVIS

1. Scan the QR code
    <br>
<a href='https://jarvis-qr.vercel.app/' target="_blank"><img alt='SCAN QR' src='https://img.shields.io/badge/Scan_qr-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>

#### DEPLOY TO HEROKU 

1. If You don't have a account in Heroku. Create a account in heroku.
    <br>
<a href='https://signup.heroku.com/' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>

3. Now Deploy
    <br>
<a href='https://jarvis-qr.vercel.app/heroku' target="_blank"><img alt='Heroku' src='https://img.shields.io/badge/-Deploy-black?style=for-the-badge&logo=heroku&logoColor=white'/></a>


#### DEPLOY TO RAILWAY

1. If You don't have a account in railway. Create a account in railway.
    <br>
<a href='https://railway.app/login' target="_blank"><img alt='railway' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=railway&logoColor=white'/></a>

2.Get [Railway api key](https://railway.app/account/tokens)

3. Now Deploy
    <br>
<a href='https://jarvis-qr.vercel.app/railway' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=railway&logoColor=white'/></a>

#### DEPLOY TO KOYEB 

1. If You don't have a account in koyeb. Create a account.
    <br>
<a href='https://app.koyeb.com/auth/signup' target="_blank"><img alt='koyeb' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

3. Get [DATABASE_URL](https://github.com/Loki-Xer/jarvis/wiki/Data-base-url) and copy it

4. Get [Koyeb api key](https://app.koyeb.com/settings/api)

2. Now Deploy
    <br>
<a href='https://jarvis-qr.vercel.app/koyeb' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=koyeb&logoColor=white'/></a>

#### DEPLOY TO PANEL

1. If You don't have a account in panel create it . 
2. How to deploy in panel?
    <br>
<a href='https://gist.github.com/IRON-M4N/2ab6496e34ec714682c7b6fb6ee86ca1' target="_blank"><img alt='PANEL' src='https://img.shields.io/badge/PANEL-100000?style=for-the-badge&logo=pterodactyl&logoColor=white&labelColor=black&color=black&logoSize=auto'/></a>

#### DEPLOY TO RENDER 

1. If You don't have a account in render. Create a account.
    <br>
<a href='https://dashboard.render.com/register' target="_blank"><img alt='render' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=render&logoColor=white'/></a>

3. Get [DATABASE_URL](https://github.com/Loki-Xer/jarvis/wiki/Data-base-url) and copy it

4. Get [Render api key](https://dashboard.render.com/u/settings#api-keys)


2. Now Deploy
    <br>
<a href='https://jarvis-qr.vercel.app/render' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=render&logoColor=white'/></a>
    
 
#### DEPLOY TO REPLIT 

 1. If You don't have a account in replit. Create a account in replit.
    <br>
<a href='https://replit.com/login' target="_blank"><img alt='railway' src='https://img.shields.io/badge/-Create-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

2. Now Deploy
    <br>
<a href='https://jarvis-qr.vercel.app/replit' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/-DEPLOY-black?style=for-the-badge&logo=replit&logoColor=white'/></a>

#### THANKS TO
- [INRL ❤️](https://github.com/inrl-official) <br>

#### JARVIS SUPPORT 



<a href="https://whatsapp.com/channel/0029Va9dOax4o7qDb6pVvp34"><img alt="WhatsApp" src="https://img.shields.io/badge/-Whatsapp%20Channel-white?style=for-the-badge&logo=whatsapp&logoColor=black"/></a>
    <br>
<br>
<a href="https://chat.whatsapp.com/HCRUrl9kCvEL6v7OhmG5BR"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>
    <br>
<br>
<a href='https://github.com/IRON-M4N/Jarvis-MD-Plugins' target="_blank"><img alt='jarvis-md' src='https://img.shields.io/badge/EXPLUGIN-100000?style=for-the-badge&logo=scan&logoColor=white&labelColor=black&color=black'/></a>
